import string
import binascii


allow_passwd = '71677a63362137387a7863626b6a31323366646764323334'


def check_password(password):
    if password == "" or password is None:
        return False
    vl = ''.join([hex(z)[2:] for z in [ord(x) for x in password]])
    return allow_passwd == vl
