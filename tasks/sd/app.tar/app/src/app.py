from flask import Flask, request

app = Flask(__name__)

from auth import check_password
import os

file_root = "/files/"


def get_file(filename):
    if os.path.exists(file_root + filename):
        f = open(file_root + filename, 'r').read()
        return f
    else:
        return None


@app.route('/')
def hello():
    return "Hello! Welcome to simple file sharing service. It is still in beta."


@app.route("/files")
def get_files():
    password = request.args.get('password')
    filename = request.args.get('filename')
    if (check_password(password)):
        if filename != "" and filename != None:
            fl = get_file(filename)
            if fl is None:
                return 'No files', 400
            else:
                return fl
        else:
            return 'No files', 400
    else:
        return 'No auth', 401


if __name__ == '__main__':
    app.run(host='0.0.0.0', port=8070)
